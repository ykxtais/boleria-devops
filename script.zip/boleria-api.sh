#!/bin/bash

# Variáveis de ambiente
RG="rg-boleria"
LOC="brazilsouth"
ASPLAN="plan-boleria"
WEBAPP="boleria-api"
SQL_SERVER="sql-boleria"
SQL_ADMIN="sqladminuser"
SQL_PASSWORD="<SUASENHA!123>"
SQL_DB="boleria_db"
AI_NAME="ai-boleria"

# Criando grupo de recursos
az group create -n $RG -l $LOC

# Criando Application Insights
az monitor app-insights component create \
  --app $AI_NAME --location $LOC --resource-group $RG --application-type web

# Criando App Service Plan (.NET 8 Linux F1)
az appservice plan create -g $RG -n $ASPLAN --sku F1 --is-linux

# Criando Web App
az webapp create -g $RG -p $ASPLAN -n $WEBAPP --runtime "DOTNETCORE:8.0"

# Criando Azure SQL Server e Banco de Dados
az sql server create -g $RG -n $SQL_SERVER -l $LOC \
  -u $SQL_ADMIN -p $SQL_PASSWORD

az sql db create -g $RG -s $SQL_SERVER -n $SQL_DB --service-objective S0

# Criando regra de firewall para Azure Services 
az sql server firewall-rule create -g $RG -s $SQL_SERVER \
  -n AllowAzureServices --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

# Configurando string de conexão no Web App
CONN="Server=tcp:${SQL_SERVER}.database.windows.net,1433;Database=${SQL_DB};User ID=${SQL_ADMIN};Password=${SQL_PASSWORD};Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
az webapp config connection-string set -g $RG -n $WEBAPP \
  --settings SqlServerDb="$CONN" --connection-string-type SQLAzure

# Configurando Application Insights no Web App
AI_CONN=$(az monitor app-insights component show -g $RG -a $AI_NAME --query connectionString -o tsv)
az webapp config appsettings set -g $RG -n $WEBAPP --settings \
  APPLICATIONINSIGHTS_CONNECTION_STRING="$AI_CONN" \
  ApplicationInsightsAgent_EXTENSION_VERSION="~3" \
  XDT_MicrosoftApplicationInsights_Mode="recommended"


# executa o DDL no banco SQL (pwsh)
pwsh -Command "Invoke-Sqlcmd -ConnectionString 'Server=tcp:${SQL_SERVER}.database.windows.net,1433;Database=${SQL_DB};User ID=${SQL_ADMIN};Password=${SQL_PASSWORD};Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;' -InputFile ./ddl.sql"

echo "Pronto"
echo "webapp: https://${WEBAPP}.azurewebsites.net"
echo "swagger: https://${WEBAPP}.azurewebsites.net/swagger"

